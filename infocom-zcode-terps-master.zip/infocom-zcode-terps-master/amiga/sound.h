
/****************************************************

Date and time of latest revision:


Tuesday 09-Jun-87 16:27:50

*******************************************************/



#define		ALL_OK			0
#define		MAIN_FILE_ERROR		1
#define		SOUND_FILE_ERROR	2
#define		MIDI_FILE_ERROR		3
#define		NO_IO_REQUEST_BLOCK	4
#define		NO_AUDIO_DEVICE		5
