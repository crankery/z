(macro fix
(
   (top_of_buffer)
   (translate "DLINE\t{*}\t" "DLINE\0 	" 1 )
))

